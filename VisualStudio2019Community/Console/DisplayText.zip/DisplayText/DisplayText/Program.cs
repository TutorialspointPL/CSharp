﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DisplayText
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // to stop the console program - RedKey function (the program is waiting for the key on the keyboard to be pressed)
            Console.ReadKey();

        }
    }
}
